CREATE TABLE Users (
    username        TEXT  PRIMARY KEY NOT NULL,
    password_hash   TEXT              NOT NULL
);


INSERT INTO Users (username, password_hash) VALUES ("jhnfrbuda58", "ozuvqiee!oùgyii%,fduyajvkqqibra64epo#b85tb");
INSERT INTO Users (username, password_hash) VALUES ("Françoismo", "ciNtm9biuFitHwwDGmo4tI63uwaVs5RSsg9izLPC");
INSERT INTO Users (username, password_hash) VALUES ("hubHubert268", "0R1nkWLYKLMJiUcGdDqi#tIhdHvZ0v0rI2P2PBQWd");
INSERT INTO Users (username, password_hash) VALUES ("HairlessNicholas", "pBYHHPfcl1I0V38MnhuRvzFcSDdU1rK9@71X0cUYv");
INSERT INTO Users (username, password_hash) VALUES ("EstebantheElfin01", "KtrmlY2GQ97jyh5NXlDtrckTGùùkVCIn7JtXiprjmN");
INSERT INTO Users (username, password_hash) VALUES ("ElOhPeeEeZed", "VG14JMxmPCanWBl7uR9QX1OKHE6nTznJ06AeEdwA");
INSERT INTO Users (username, password_hash) VALUES ("LeonardoNardo", "P4OILOJHii7jtFvYlvQ7qpgoPbWR4daKoYrrCKCd");
INSERT INTO Users (username, password_hash) VALUES ("JellyVadar", "c4rPqKdaqfYeI0pwjgktV2eDCFsib9MIWAk7XqmJ");
INSERT INTO Users (username, password_hash) VALUES ("DarthBarth", "YVFFk0E6FuLWPNaZtrBTtQntMndOIq9kamzqU3CO");
INSERT INTO Users (username, password_hash) VALUES ("CreepyChristine121", "RSO60CF4cS6UnVIBnHbvQq8blq0zOiBbSYi9TIwx");
INSERT INTO Users (username, password_hash) VALUES ("VilerNMiller", "rZvyVBF8LDfYDUOSieRgO5HS6ukJUj0o4IF3bbyP");
INSERT INTO Users (username, password_hash) VALUES ("20CrazyBaby", "68the7HeHyjlvogoSAutP8VeVD24KqIHf1c5Rzv9b");
INSERT INTO Users (username, password_hash) VALUES ("onepac", "ehkR12bdv2yaNTIdq4n0MroNffn4L3YAFvbEIAKF");
INSERT INTO Users (username, password_hash) VALUES ("onepeny", "d4YBNXtAF69Ijv0vU7TbDcflfTLSwoPWAKa8jDWe")
