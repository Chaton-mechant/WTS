INSERT INTO identity_info (id, name, work, born_date, born_city) VALUES (1, 'John', 'Ingeneer', '1997-01-01 00:00:00', 'Budapest');
INSERT INTO identity_info (id, name, work, born_date, born_city) VALUES (2, 'Peter', 'Doctor', '1993-03-02 00:06:10', 'Paris');
INSERT INTO identity_info (id, name, work, born_date, born_city) VALUES (3, 'Mary', 'Teacher', '1990-01-01 00:00:00', 'Rome');
INSERT INTO identity_info (id, name, work, born_date, born_city) VALUES (4, 'Marcus', 'Tailer', '2000-07-01 00:00:00', 'London');
